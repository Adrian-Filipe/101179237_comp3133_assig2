const mongoose = require("mongoose");
HotelSchema = new mongoose.Schema({
    hotel_id: {
        type: Number,
        required: true,
        unique: true
    },

    hotel_name: {
        type: String,
        required: true
    },

    street: {
        type: String,
        required: true
    },

    city: {
        type: String,
        required: true
    },

    postal_code: {
        type: String,
        required: true,
        validate(value){
            var regex = /^[0-9A-Za-z]{6}$/;
            return regex.test(value);
        }
    },

    price: {
        type: Number,
        required: true
    },

    email: {
        type: String,
        required: true,
        validate(value){
            var regex = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            return regex.test(value);
        }
    },

    user_id: {
        type: Number,
        required: true
    }
})
const Hotel = mongoose.model("Hotel", HotelSchema);
module.exports = Hotel;