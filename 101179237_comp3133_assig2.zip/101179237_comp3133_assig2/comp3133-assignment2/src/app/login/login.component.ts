import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router'
// import { DatabaseService } from '../database.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent {

  userName:string;
  password:string;
  loginID = 0;
  message = ""

  constructor(private router: Router) {
    this.userName = "";
    this.password = "";
  }

  ngOnInit(): void {

  }

  onSubmit(loginForm: NgForm) {
    this.userName = loginForm.value.userName
    this.password = loginForm.value.password

    if (this.userName == localStorage.getItem("username") && this.password == localStorage.getItem("password")) {
      // this.database.setUsername(this.userName)
      // this.database.setPassword(this.password)
      localStorage.setItem("isUserLogin", "true");
      this.router.navigate(["/dashboard"])
    }else {
      localStorage.setItem("isUserLogin", 'false');
      this.message = "Invalid username or password!"
    }
  }
}
