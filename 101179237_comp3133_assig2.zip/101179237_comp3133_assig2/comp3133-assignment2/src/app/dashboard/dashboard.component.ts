import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {

  hotels = [{"hotel_id":1, "hotel_name":"Hilton Inn", "street":"Younge Street", "city":"Toronto", "postal_code":"M1X0Y5", "price":150, "email":"Hilton_Inn@hotmail.com", "user_id":2},
  {"hotel_id":2, "hotel_name":"Sandy Beaches", "street":"Fort York", "city":"Toronto", "postal_code":"D1W4RX", "price":200, "email":"Sandy-Beaches@gmail.com", "user_id":3},
  {"hotel_id":3, "hotel_name":"Punta Cana Resort", "street":"Bayview", "city":"Richmondhill", "postal_code":"LO890T", "price":250, "email":"PuntaCanaResort@gmail.com", "user_id":4}]

  bookings = [
    {"booking_id":1, "hotel_id":1, "booking_date":"01-24-2021", "booking_start":"01-25-2021", "booking_end":"01-30-2021", "user_id":3},
    {"booking_id":2, "hotel_id":2, "booking_date":"01-24-2021", "booking_start":"01-26-2021", "booking_end":"01-30-2021", "user_id":2},
    {"booking_id":3, "hotel_id":1, "booking_date":"01-25-2021", "booking_start":"01-28-2021", "booking_end":"01-30-2021", "user_id":4},
    {"booking_id":4, "hotel_id":3, "booking_date":"01-26-2021", "booking_start":"01-27-2021", "booking_end":"01-31-2021", "user_id":1}]

  constructor(private router: Router) { }

  ngOnInit(): void {
    if(!localStorage.getItem("isUserLogin")) {
      this.router.navigate(["/login"])
    }
  }

}
