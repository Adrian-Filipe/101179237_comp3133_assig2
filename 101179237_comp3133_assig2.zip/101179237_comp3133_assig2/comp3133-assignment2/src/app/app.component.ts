import { Component } from '@angular/core';
// import { Routes } from './routes.js'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  isUserLogin = 'false'

  constructor() {

  }

  ngOnInit() {
    let data = localStorage.getItem("isUserLogin");
     if(data != null && data == "true") {
       this.isUserLogin = 'true'
     }else {
       this.isUserLogin = 'false'
     }
  }

}


