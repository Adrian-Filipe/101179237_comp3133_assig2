const express = require("express");
const mongoose = require("mongoose");
const {graphqlHTTP} = require("express-graphql");
const {buildSchema} = require("graphql");
const hotelModel = require("./modules/Hotel");
const bookingModel = require("./modules/Booking");
const userModel = require("./modules/User");
const app = express();

mongoose.connect("mongodb+srv://Nuttjob:Spanyolo@cluster0.9rpji.mongodb.net/Assignment1?retryWrites=true&w=majority", {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

var hotelSchema = buildSchema(
    `type Query {
        hotels: [Hotel]
        hotel_name: [Hotel]
        city: [Hotel]
    },
    type Hotel {
        hotel_id: Int
        hotel_name: String
        street: String
        city: String
        postal_code: String
        price: Float
        email: String
        user_id: Int
    }`
)

var bookingSchema = buildSchema(
    `type Query {
        bookings: [Booking]
    },
    type Booking {
        booking_id: Int
        hotel_id: Int
        booking_date: String
        booking_start: String
        booking_end: String
        user_id: Int
    }`
)

var userSchema = buildSchema(
    `type Query {
        users: [User]
    },
    type User {
        user_id: Int
        username: String
        password: String
        email: String
    }`
)

var hotelRoot = {
    hotels: hotelModel.find({}),
    hotel_name: hotelModel.find({"hotel_name":"Hilton Inn"}),
    city: hotelModel.find({"city":"Toronto"})
}

var bookingRoot = {
    bookings: bookingModel.find({}),
}

var userRoot = {
    users: userModel.find({}),
}

app.use("/graphql/hotels", graphqlHTTP({
    schema: hotelSchema,
    rootValue: hotelRoot,
    graphiql: true
}))

app.use("/graphql/bookings", graphqlHTTP({
    schema: bookingSchema,
    rootValue: bookingRoot,
    graphiql: true
}))

app.use("/graphql/users", graphqlHTTP({
    schema: userSchema,
    rootValue: userRoot,
    graphiql: true
}))

app.get("/hotels", async (req,res) =>{
    var hotels;
    var name = req.query.name;
    var city = req.query.city;
    if(name != null){
        hotels = await hotelModel.find({"hotel_name":name})
    }
    else if(city != null){
        hotels = await hotelModel.find({"city":city})
    }
    else{
        hotels = await hotelModel.find({})
    }
    try{
        res.status(200).send(hotels);
    }catch(err){
        res.status(500).send(err);
    }
})

app.get("/bookings", async (req,res) =>{
    const bookings = await bookingModel.find({})
    try{
        res.status(200).send(bookings);
    }catch(err){
        res.status(500).send(err);
    }
})

app.get("/users", async (req,res) =>{
    const users = await userModel.find({})
    try{
        res.status(200).send(users);
    }catch(err){
        res.status(500).send(err);
    }
})

app.listen(8081, () => {
    console.log("Express Server is now up!")
})

bookingModel.create([
    {"booking_id":1, "hotel_id":1, "booking_date":"01-24-2021", "booking_start":"01-25-2021", "booking_end":"01-30-2021", "user_id":3},
    {"booking_id":2, "hotel_id":2, "booking_date":"01-24-2021", "booking_start":"01-26-2021", "booking_end":"01-30-2021", "user_id":2},
    {"booking_id":3, "hotel_id":1, "booking_date":"01-25-2021", "booking_start":"01-28-2021", "booking_end":"01-30-2021", "user_id":4},
    {"booking_id":4, "hotel_id":3, "booking_date":"01-26-2021", "booking_start":"01-27-2021", "booking_end":"01-31-2021", "user_id":1}
])

hotelModel.create([
    {"hotel_id":1, "hotel_name":"Hilton Inn", "street":"Younge Street", "city":"Toronto", "postal_code":"M1X0Y5", "price":150, "email":"Hilton_Inn@hotmail.com", "user_id":2},
    {"hotel_id":2, "hotel_name":"Sandy Beaches", "street":"Fort York", "city":"Toronto", "postal_code":"D1W4RX", "price":200, "email":"Sandy-Beaches@gmail.com", "user_id":3},
    {"hotel_id":3, "hotel_name":"Punta Cana Resort", "street":"Bayview", "city":"Richmondhill", "postal_code":"LO890T", "price":250, "email":"PuntaCanaResort@gmail.com", "user_id":4}
])

userModel.create([
    {"user_id":1, "username":"Henry", "password":"henry_123", "email":"Henry-Lawman@hotmail.com"},
    {"user_id":2, "username":"Jenkins", "password":"j8hy_@d1", "email":"Leroy-Jenkins@gmail.com"},
    {"user_id":3, "username":"Sarah", "password":"sarah@346", "email":"Sarah-Castle@hotmail.com"},
    {"user_id":4, "username":"Morgan", "password":"574_morgan_678", "email":"Morgan-Freeman@hotmail.com"}
])
module.exports = Routes;
