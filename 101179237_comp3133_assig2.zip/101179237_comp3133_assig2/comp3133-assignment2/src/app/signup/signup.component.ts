import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router'
// import { DatabaseService } from '../database.service'

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  userName:string;
  password:string;
  email:string;
  loginID = 0;
  message = "";

  constructor(private router: Router) {
    this.userName = "";
    this.password = "";
    this.email = "";
  }

  ngOnInit(): void {
  }

  onSubmit(loginForm: NgForm) {
    this.userName = loginForm.value.userName
    this.password = loginForm.value.password
    this.email = loginForm.value.email

    if (this.userName != "" && this.password != "" && this.email != "") {
      // this.database.setUsername(this.userName)
      // this.database.setPassword(this.password)
      localStorage.setItem("username", loginForm.value.userName);
      localStorage.setItem("password", loginForm.value.password);
      localStorage.setItem("email", loginForm.value.email);
      this.router.navigate(["/dashboard"])
    }else {
      localStorage.setItem("isUserLogin", 'false');
      this.message = "Invalid username or password!"
    }
  }

}
