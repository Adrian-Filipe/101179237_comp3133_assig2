import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Subject } from 'rxjs'
import { gql, Apollo } from 'apollo-angular'

@Injectable({
  providedIn: 'root'
})

export class DatabaseService {

  user_id: Number
  username: String
  password: String
  email: String
  user_data: any

  constructor(private http: HttpClient, private ap: Apollo) {
    this.user_id = 0;
    this.username = "";
    this.password = ""
    this.email = ""
  }

  getUsername() {
    return this.username
  }

  setUsername(username: String) {
    this.username = username
    return this.username
  }

  getPassword() {
    return this.password
  }

  setPassword(password: String) {
    this.password = password
    return this.password
  }

  gql_Users = gql`{
    users{
      user_id
      username,
      email,
      password
    }
  }`

  gql_create_user = gql`{
    mutation createUser($user_id:Number, $username:String, $email:String, $password:String)
    createUser(
      user_id: $user_id,
      username: $username,
      email: $email,
      password: $password
    ){
      user_id,
      username,
      email,
      password
    }
  }`

  gql_Hotels = gql`{
    hotels{
      hotel_id
      hotel_name,
      street,
      city,
      postal_code,
      price,
      email
      user_id
    }
  }`

  gql_Bookings = gql`{
    bookings{
      booking_id,
      hotel_id,
      booking_date,
      booking_start,
      booking_end,
      user_id
    }
  }`

}
